import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Dashboard {
    public Dashboard() {
        JFrame frame = new JFrame("Dashboard");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.setLayout(null);
        frame.getContentPane().setBackground(new Color(144, 238, 144)); // Light green background

        // Buttons
        JButton loginButton = new JButton("Login");
        loginButton.setBounds(50, 100, 150, 40);

        JButton registerButton = new JButton("Register");
        registerButton.setBounds(50, 200, 150, 40);

        JButton itemManagementButton = new JButton("Item Management");
        itemManagementButton.setBounds(50, 300, 150, 40);

        JButton logoutButton = new JButton("Logout");
        logoutButton.setBounds(600, 20, 100, 30);
        logoutButton.setBackground(new Color(200, 0, 0)); // Red color for Logout button
        logoutButton.setForeground(Color.WHITE);

        // Add buttons to the frame
        frame.add(loginButton);
        frame.add(registerButton);
        frame.add(itemManagementButton);
        frame.add(logoutButton);

        // Button actions
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Open the LoginGUI
                LoginGUI.main(frame);
            }
        });

        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Open the RegisterGUI
                RegistrationLoginGUI.main(null);
            }
        });

        itemManagementButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Open the ItemManagementApp
                ItemManagementApp.main(null);
            }
        });

        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Implement logout functionality here
                JOptionPane.showMessageDialog(frame, "Logged out.");
            }
        });

        frame.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new Dashboard();
            }
        });
    }
}
