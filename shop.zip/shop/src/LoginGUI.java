import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class LoginGUI extends JPanel { // Extend JPanel
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JFrame frame; // Reference to the parent frame

    public LoginGUI(JFrame frame) {
        this.frame = frame; // Store the reference to the parent frame

        setLayout(null);

        // Components
        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setBounds(10, 10, 80, 25);
        usernameField = new JTextField();
        usernameField.setBounds(140, 10, 200, 25);

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(10, 40, 80, 25);
        passwordField = new JPasswordField();
        passwordField.setBounds(140, 40, 200, 25);

        JButton loginButton = new JButton("Login");
        loginButton.setBounds(140, 70, 100, 25);

        // Set button and background colors
        loginButton.setBackground(new Color(0, 102, 204));
        loginButton.setForeground(Color.WHITE);
        frame.getContentPane().setBackground(new Color(173, 216, 230));

        add(usernameLabel);
        add(usernameField);
        add(passwordLabel);
        add(passwordField);
        add(loginButton);

        // Database connection
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/online_shop_db", "root", "silas1256");
            UserDAO userDAO = new UserDAO(connection);

            loginButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String username = usernameField.getText();
                    String password = new String(passwordField.getPassword());

                    if (username.isEmpty() || password.isEmpty()) {
                        JOptionPane.showMessageDialog(frame, "Username and password are required.");
                    } else {
                        try {
                            boolean loggedIn = userDAO.login(username, password);
                            if (loggedIn) {
                                openItemManagementApp(); // Show the ItemManagementApp in a new window
                            } else {
                                JOptionPane.showMessageDialog(frame, "Invalid username or password.");
                            }
                        } catch (SQLException ex) {
                            ex.printStackTrace();
                            JOptionPane.showMessageDialog(frame, "Login failed.");
                        }
                    }
                }
            });

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Database connection failed.");
        }
    }

    public LoginGUI() {

    }

    public static void showLoginGUI(JFrame frame, ItemManagementApp itemManagementApp) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new LoginGUI(frame);
            }
        });
    }

    private void openItemManagementApp() {
        SwingUtilities.invokeLater(new Runnable() {
            private Object frame;

            @Override
            public void run() {
                // Pass the frame reference to ItemManagementApp
                new ItemManagementApp(this.frame);
            }
        });
    }


    public static void main(JFrame args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Login");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(400, 200);

            // Create an instance of LoginGUI and add it to the frame
            LoginGUI loginGUI = new LoginGUI(frame);
            frame.add(loginGUI);

            // Make the frame visible
            frame.setVisible(true);
        });
    }

    public boolean login() {
        return false;
    }
}