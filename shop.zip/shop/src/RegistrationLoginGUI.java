import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class RegistrationLoginGUI {


    public RegistrationLoginGUI(JFrame frame) {

    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("User Registration and Login");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 250);
        frame.setLayout(null);

        // Components
        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setBounds(10, 10, 80, 25);
        JTextField usernameField = new JTextField();
        usernameField.setBounds(140, 10, 200, 25);

        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setBounds(10, 40, 80, 25);
        JTextField emailField = new JTextField();
        emailField.setBounds(140, 40, 200, 25);

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(10, 70, 80, 25);
        JPasswordField passwordField = new JPasswordField();
        passwordField.setBounds(140, 70, 200, 25);

        JLabel confirmPasswordLabel = new JLabel("Confirm Password:");
        confirmPasswordLabel.setBounds(10, 100, 120, 25);
        JPasswordField confirmPasswordField = new JPasswordField();
        confirmPasswordField.setBounds(140, 100, 200, 25);

        JButton registerButton = new JButton("Register");
        registerButton.setBounds(140, 130, 100, 25);
        JButton loginButton = new JButton("Login");
        loginButton.setBounds(250, 130, 90, 25);

        // Add components to the frame
        frame.add(usernameLabel);
        frame.add(usernameField);
        frame.add(emailLabel);
        frame.add(emailField);
        frame.add(passwordLabel);
        frame.add(passwordField);
        frame.add(confirmPasswordLabel);
        frame.add(confirmPasswordField);
        frame.add(registerButton);
        frame.add(loginButton);

        // Set button colors
        registerButton.setBackground(new Color(0, 102, 204));
        registerButton.setForeground(Color.WHITE);
        loginButton.setBackground(new Color(204, 0, 0));
        loginButton.setForeground(Color.WHITE);

        // Database connection
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/online_shop_db", "root", "silas1256");
            UserDAO userDAO = new UserDAO(connection);

            registerButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String username = usernameField.getText();
                    String email = emailField.getText();
                    String password = new String(passwordField.getPassword());
                    String confirmPassword = new String(confirmPasswordField.getPassword());

                    if (username.isEmpty() || email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
                        JOptionPane.showMessageDialog(frame, "All fields are required.");
                    } else if (!password.equals(confirmPassword)) {
                        JOptionPane.showMessageDialog(frame, "Passwords do not match.");
                    } else {
                        try {
                            boolean registered = userDAO.registerUser(username, password);
                            if (registered) {
                                JOptionPane.showMessageDialog(frame, "Registration successful.");
                            } else {
                                JOptionPane.showMessageDialog(frame, "User already exists. Please log in.");
                            }
                        } catch (SQLException ex) {
                            ex.printStackTrace();
                            JOptionPane.showMessageDialog(frame, "Registration failed.");
                        }
                    }
                }
            });

            loginButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    // Your login logic here
                }
            });
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Database connection failed.");
        }

        frame.setVisible(true);
    }

    public static void showRegistrationLoginGUI(JFrame frame) {

    }

    public static void register() {

    }

    public static <Dashboard> JPanel createRegisterPanel(Dashboard dashboard) {


        return null;
    }
}
