import javax.swing.*;
import java.awt.*;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ItemManagementApp {
    private DefaultListModel<Item> itemListModel;
    private JList<Item> itemList;
    private JFrame frame;
    private boolean loggedIn;

    public ItemManagementApp(Object frame) {
        this.loggedIn = false;
        this.frame = new JFrame("Item Management App");
        this.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.frame.setSize(600, 400);
        this.frame.getContentPane().setBackground(Color.BLUE);

        // Create a DefaultListModel to store items
        itemListModel = new DefaultListModel<>();
        itemList = new JList<>(itemListModel);
        itemList.setCellRenderer(new ItemCellRenderer());
        itemList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        // Enable item dragging and dropping
        itemList.setDragEnabled(true);
        itemList.setTransferHandler(new ItemTransferHandler());

        // Create buttons
        JButton addButton = new JButton("Add Item");
        JButton deleteButton = new JButton("Delete Selected");
        JButton customizeButton = new JButton("Customize");
        JButton adminApproveButton = new JButton("Admin Approve");
        JButton purchaseButton = new JButton("Purchase");
        JButton logoutButton = new JButton("Logout");

        // Change button colors
        addButton.setBackground(Color.GREEN);
        addButton.setForeground(Color.WHITE);
        deleteButton.setBackground(Color.RED);
        deleteButton.setForeground(Color.WHITE);
        customizeButton.setBackground(Color.YELLOW);
        customizeButton.setForeground(Color.BLACK);
        adminApproveButton.setBackground(Color.CYAN);
        adminApproveButton.setForeground(Color.BLACK);
        purchaseButton.setBackground(Color.ORANGE);
        purchaseButton.setForeground(Color.BLACK);

        // Add action listeners to buttons
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (loggedIn) {
                    String itemName = JOptionPane.showInputDialog(ItemManagementApp.this.frame, "Enter Item Name:");
                    if (itemName != null && !itemName.isEmpty()) {
                        double itemPrice = Double.parseDouble(JOptionPane.showInputDialog(ItemManagementApp.this.frame, "Enter Item Price:"));
                        int itemQuantity = Integer.parseInt(JOptionPane.showInputDialog(ItemManagementApp.this.frame, "Enter Item Quantity:"));
                        Item newItem = new Item(itemName, itemPrice, itemQuantity);
                        itemListModel.addElement(newItem);

                        // Save the item to the database
                        saveItemToDatabase(newItem);
                    }
                } else {
                    JOptionPane.showMessageDialog(ItemManagementApp.this.frame, "You must log in to add items.");
                }
            }
        });

        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedIndex = itemList.getSelectedIndex();
                if (selectedIndex != -1) {
                    itemListModel.remove(selectedIndex);
                }
            }
        });

        customizeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Customize the font size and text color here
                Font newFont = new Font("Arial", Font.BOLD, 16);
                Color newColor = Color.RED;
                itemList.setFont(newFont);
                itemList.setForeground(newColor);
            }
        });

        adminApproveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Item selectedItem = itemList.getSelectedValue();
                if (selectedItem != null) {
                    // Simulate admin approval by changing item status
                    selectedItem.setApproved(true);
                    itemList.repaint();
                }
            }
        });

        purchaseButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Item selectedItem = itemList.getSelectedValue();
                if (selectedItem != null) {
                    // Ask the user for the quantity needed
                    int quantityNeeded = Integer.parseInt(JOptionPane.showInputDialog(ItemManagementApp.this.frame, "Enter Quantity Needed:"));
                    if (quantityNeeded <= selectedItem.getQuantity()) {
                        double totalCost = quantityNeeded * selectedItem.getPrice();
                        JOptionPane.showMessageDialog(ItemManagementApp.this.frame, "Total Cost: $" + totalCost, "Purchase Complete", JOptionPane.INFORMATION_MESSAGE);
                        // Update the quantity in stock
                        selectedItem.setQuantity(selectedItem.getQuantity() - quantityNeeded);
                    } else {
                        JOptionPane.showMessageDialog(ItemManagementApp.this.frame, "Insufficient stock!", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });
        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loggedIn = false;
                JOptionPane.showMessageDialog(ItemManagementApp.this.frame, "Logged out.");
                ItemManagementApp.this.frame.dispose();
            }
        });
        // Create a JScrollPane for the item list
        JScrollPane scrollPane = new JScrollPane(itemList);

        // Add the buttons to a panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout());
        buttonPanel.add(addButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(customizeButton);
        buttonPanel.add(adminApproveButton);
        buttonPanel.add(purchaseButton);
        buttonPanel.add(logoutButton);



        // Create a JPanel for the entire content
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BorderLayout());
        contentPanel.add(scrollPane, BorderLayout.CENTER);
        contentPanel.add(buttonPanel, BorderLayout.SOUTH);

        this.frame.add(contentPanel);

        // Add a footer
        JPanel footerPanel = new JPanel();
        footerPanel.setBackground(Color.BLUE);
        JLabel footerLabel = new JLabel("Development by Gloria Auma: IN16/00050/21, Silas Denis:IN16/00017/19, Morgan Okumu:IN16/00053/21");
        footerLabel.setForeground(Color.WHITE);
        footerPanel.add(footerLabel);
        this.frame.add(footerPanel, BorderLayout.SOUTH);

        this.frame.setVisible(true);
    }

    public static void main(Object o) {
        SwingUtilities.invokeLater(new Runnable() {
            private Object frame;

            public void run() {
                new ItemManagementApp(this.frame);
            }
        });
    }


    private void saveItemToDatabase(Item item) {
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/online_shop_db", "root", "silas1256")) {
            String query = "INSERT INTO item (name, price, quantity) VALUES (?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, item.getName());
                preparedStatement.setDouble(2, item.getPrice());
                preparedStatement.setInt(3, item.getQuantity());
                preparedStatement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Error saving the item to the database.");
        }
    }




    public void setVisible(boolean b) {

    }

    private class ItemCellRenderer extends DefaultListCellRenderer {
        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
            super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            if (value instanceof Item) {
                Item item = (Item) value;
                String text = item.getName() + " ($" + item.getPrice() + ") Qty: " + item.getQuantity();
                if (item.isApproved()) {
                    setForeground(Color.GREEN);
                } else {
                    setForeground(Color.RED);
                    text += " (Pending Approval)";
                }
                setText(text);
            }
            return this;
        }
    }
}

class ItemTransferHandler extends TransferHandler {
    @Override
    public int getSourceActions(JComponent c) {
        return TransferHandler.MOVE;
    }

    @Override
    protected Transferable createTransferable(JComponent c) {
        JList<Item> source = (JList<Item>) c;
        return new ItemTransferable(source.getSelectedValue());
    }

    @Override
    protected void exportDone(JComponent source, Transferable data, int action) {
        if (action == TransferHandler.MOVE) {
            JList<Item> sourceList = (JList<Item>) source;
            DefaultListModel<Item> model = (DefaultListModel<Item>) sourceList.getModel();
            int index = sourceList.getSelectedIndex();
            if (index != -1) {
                model.remove(index);
            }
        }
    }
}

class ItemTransferable implements Transferable {
    private Item item;

    public ItemTransferable(Item item) {
        this.item = item;
    }

    @Override
    public DataFlavor[] getTransferDataFlavors() {
        return new DataFlavor[]{ItemFlavor.ITEM_FLAVOR};
    }

    @Override
    public boolean isDataFlavorSupported(DataFlavor flavor) {
        return flavor.equals(ItemFlavor.ITEM_FLAVOR);
    }

    @Override
    public Object getTransferData(DataFlavor flavor) {
        if (isDataFlavorSupported(flavor)) {
            return item;
        } else {
            return null;
        }
    }
}

class ItemFlavor extends DataFlavor {
    public static final DataFlavor ITEM_FLAVOR = new DataFlavor(Item.class, "Item");

    public ItemFlavor(Class<?> representationClass, String humanPresentableName) {
        super(representationClass, humanPresentableName);
    }
}

class Item {
    private String name;
    private double price;
    private int quantity;
    private boolean approved;

    public Item(String name, double price, int quantity, boolean approved) {
        this.name = name;
        this.price = price;
        this.quantity = quantity;
        this.approved = false;
    }

    public Item(String itemName, double itemPrice, int itemQuantity) {

    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public boolean isApproved() {
        return approved;
    }

    public void setApproved(boolean approved) {
        this.approved = approved;
    }

    @Override
    public String toString() {
        return name;
    }

}
